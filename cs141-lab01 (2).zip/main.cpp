//
// Author: ADA PICI, UIC, Spring 2021
//Assignment: Lab 01
//

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
    string filename;
    filename = "input1.txt";
    string filename2;
    filename2 = "output2.txt";
    cout << "Please enter input filename> ";
    cin >> filename;
    cout << endl;
    cout << "Please enter output filename> ";
    cin >> filename2;
    cout << endl;
   
    ifstream infile;
    
    ofstream outfile; 
    outfile.open(filename2);
   infile.open(filename);
   if (!infile.good())  // file is NOT good, i.e. could not be opened:
     {
        cout << "**Error: unable to open input file '" << filename << "'" << endl;
        return 0;  // return now since we cannot continue without input file
     } 
    
     
   int num1, num2, num3, num4;
   infile >> num1;
   infile >> num2;
   infile >> num3;
   infile >> num4;
   
    
    
   double sum;
   sum = static_cast<double>(num1 + num2 + num3 + num4);
   outfile << sum << endl;
   
   cout << sum << endl;
          
   double avg;
          avg = static_cast<double>(num1 + num2 +num3 + num4)/ 4.0;
   outfile << avg << endl;
   
    cout << avg << endl;
    outfile.close();        
   infile.close();
   return 0;
}
